﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <IdHashSHA.hpp>
#include "..\dllk\mydllform.h"
#include "Login.h"
#include "Register.h"
#include <pngimage.hpp>
#include <jpeg.hpp>
#include <map>
#include <IniFiles.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Signatory"
#pragma resource "*.dfm"
#include "Homepage.h"
TForm1 *Form1;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	translation["Name"] =  {
	{
		{"US", "First Name"},
		{"HR", "Ime"}
	}
	};
	translation["Label1"] =  {
	{
		{"US", "Last Name"},
		{"HR", "Prezime"}
	}
	};
	translation["Label3"] =  {
	{
		{"US", "Username"},
		{"HR", "Korisničko ime"}
	}
	};
	translation["Label4"] =  {
	{
		{"US", "Password"},
		{"HR", "Šifra"}
	}
	};
	translation["Register"] =  {
	{
		{"US", "Register"},
		{"HR", "Registriraj se"}
	}
	};translation["Button1"] =  {
	{
		{"US", "I have an account"},
		{"HR", "Već imam profil"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Početna"}
	}
	};

}
//---------------------------------------------------------------------------
void __fastcall TForm1::RegisterClick(TObject *Sender){
String Sol;
if (Pass->Text.Length() < 6) {
    Sol = "TOP";
} else {
	Sol = "BOT";
}


Codec1->Password = "Crypt";
String CodedFirstName;
Codec1->EncryptString(FirstName->Text, CodedFirstName, TEncoding::UTF8);


String PossiblePapars[] = {"papar1", "papar2", "papar3"};
String Papar = PossiblePapars[rand() % (sizeof(PossiblePapars) / sizeof(PossiblePapars[0]))];
TIdHashSHA1* sha1 = new TIdHashSHA1;
String hashedPassword = sha1->HashStringAsHex(Pass->Text + Sol + Papar);

ADOTable1->Insert();
ADOTable1->FieldByName("First Name")->AsString = CodedFirstName;
ADOTable1->FieldByName("Last Name")->AsString = LastName->Text;
ADOTable1->FieldByName("Username")->AsString = User->Text;
ADOTable1->FieldByName("Password")->AsString = hashedPassword;
try {
	ADOTable1->Insert();
	TForm11* dllForm = new TForm11(this);
	dllForm->ShowModal();
	Form2->Show();
	this->Hide();
} catch (Exception &e) {
	ShowMessage("Error: " + e.Message);
}
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
Form2->Show();
this->Hide();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::ComboBox1Change(TObject *Sender)
{
 translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------





void __fastcall TForm1::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "\\..\\ProjektLanguage.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

