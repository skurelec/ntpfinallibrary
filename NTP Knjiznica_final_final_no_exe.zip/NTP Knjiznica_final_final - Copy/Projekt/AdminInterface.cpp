﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "AdminInterface.h"
#include <IdHashSHA.hpp>
#include <map>
#include <memory>
#include "LoginAdmin.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Signatory"
#pragma resource "*.dfm"
#include <IniFiles.hpp>
#include "Homepage.h"
TForm7 *Form7;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm7::TForm7(TComponent* Owner)
	: TForm(Owner)
{
translation["Label5"] =  {
	{
		{"US", "First Name"},
		{"HR", "Ime"}
	}
	};
translation["Label2"] =  {
	{
		{"US", "Last Name"},
		{"HR", "Prezime"}
	}
	};
translation["Label3"] =  {
	{
		{"US", "Username"},
		{"HR", "Korisnicko ime"}
	}
	};
translation["Label4"] =  {
	{
		{"US", "Password"},
		{"HR", "Šifra"}
	}
	};
translation["Button6"] =  {
	{
		{"US", "Insert New"},
		{"HR", "Dodaj novi"}
	}
	};
	translation["Button7"] =  {
	{
		{"US", "Update Selected"},
		{"HR", "Ažuriraj odabrano"}
	}
	};
translation["Button8"] =  {
	{
		{"US", "Delete Selected"},
		{"HR", "Izbriši odabrano"}
	}
	};
translation["button7"] =  {
	{
		{"US", "Update Selected"},
		{"HR", "Ažuriraj odabrano"}
	}
	};
translation["Label6"] =  {
	{
		{"US", "Insert monthly hours"},
		{"HR", "Ubaci mjesecne sate"}
	}
	};
translation["Button9"] =  {
	{
		{"US", "Insert"},
		{"HR", "Ubaci"}
	}
	};
translation["Button10"] =  {
	{
		{"US", "Delete"},
		{"HR", "Izbriši"}
	}
	};
translation["Button5"] =  {
	{
		{"US", "10kb/s"},
		{"HR", "10kb/s"}
	}
	};
translation["Button4"] =  {
	{
		{"US", "20kb/s"},
		{"HR", "20kb/s"}
	}
	};
translation["Button3"] =  {
	{
		{"US", "80kb/s"},
		{"HR", "80kb/s"}
	}
	};
translation["Button1"] =  {
	{
		{"US", "HTTP Instructions"},
		{"HR", "HTTP Upute"}
	}
	};
translation["Button2"] =  {
	{
		{"US", "Abort"},
		{"HR", "Prekini"}
	}
	};
    translation["Button13"] =  {
	{
		{"US", "Get Keys"},
		{"HR", "Ključevi"}
	}
	};
translation["Button11"] =  {
	{
		{"US", "Encrypt"},
		{"HR", "Kriptiraj"}
	}
	};
translation["Button12"] =  {
	{
		{"US", "Decrypt"},
		{"HR", "Dekriptiraj"}
	}
	};
translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Početna"}
	}
	};
translation["Button14"] =  {
	{
		{"US", "Expected Pay In HRK"},
		{"HR", "Očekivana Plača u HRK"}
	}
	};



}
//---------------------------------------------------------------------------
void __fastcall TForm7::Button1Click(TObject *Sender)
{
TFileStream* fs = new TFileStream("instructions.pdf",fmCreate);
Download->Get("https://www.w3.org/Protocols/HTTP/1.1/rfc2616.pdf",fs);
delete fs;
}
//---------------------------------------------------------------------------
void __fastcall TForm7::DownloadWorkBegin(TObject *ASender, TWorkMode AWorkMode, __int64 AWorkCountMax)

{
ProgressBar1->Position = 0;
ProgressBar1->Max = AWorkCountMax;
}
//---------------------------------------------------------------------------
void __fastcall TForm7::DownloadWork(TObject *ASender, TWorkMode AWorkMode, __int64 AWorkCount)

{
ProgressBar1->Position = AWorkCount;

int Percentage = (AWorkCount * 100) / ProgressBar1->Max;
Label7->Caption = IntToStr(Percentage) + "%";

Application->ProcessMessages();
}
//---------------------------------------------------------------------------
void __fastcall TForm7::Button2Click(TObject *Sender)
{
Download->Disconnect();
}
//---------------------------------------------------------------------------
void __fastcall TForm7::Button5Click(TObject *Sender)
{
Throttler->BitsPerSec = 81920;
}
//---------------------------------------------------------------------------
void __fastcall TForm7::Button4Click(TObject *Sender)
{
Throttler->BitsPerSec = 163840;
}
//---------------------------------------------------------------------------
void __fastcall TForm7::Button3Click(TObject *Sender)
{
Throttler->BitsPerSec = 655360;
}
//---------------------------------------------------------------------------
void __fastcall TForm7::Button6Click(TObject *Sender)
{
String Sol;
if (Password->Text.Length() < 6) {
	Sol = "TOP";
} else {
	Sol = "BOT";
}

String PossiblePapars[] = {"papar1", "papar2", "papar3"};
String Papar = PossiblePapars[rand() % (sizeof(PossiblePapars) / sizeof(PossiblePapars[0]))];
TIdHashSHA1* sha1 = new TIdHashSHA1;
String hashedPassword = sha1->HashStringAsHex(Password->Text + Sol + Papar);

ADOTable1->Insert();
ADOTable1->FieldByName("First Name")->AsString = FirstName->Text;
ADOTable1->FieldByName("Last Name")->AsString = LastName->Text;
ADOTable1->FieldByName("Username")->AsString = Username->Text;
ADOTable1->FieldByName("Password")->AsString = hashedPassword;
ADOTable1->Post();

}

//---------------------------------------------------------------------------


void __fastcall TForm7::Button8Click(TObject *Sender)
{
ADOTable1->Delete();
}
//---------------------------------------------------------------------------


void __fastcall TForm7::Button7Click(TObject *Sender)
{

ADOTable1->Edit();
ADOTable1->FieldByName("First Name")->AsString = FirstName->Text;
ADOTable1->FieldByName("Last Name")->AsString = LastName->Text;
ADOTable1->FieldByName("Username")->AsString = Username->Text;

}
//---------------------------------------------------------------------------


void __fastcall TForm7::Button9Click(TObject *Sender)
{
ADOTable1->Edit();
ADOTable1->FieldByName("Monthly Hours")->AsString = Hours->Text;
ADOTable1->FieldByName("Expected Pay In €")->AsString = Hours->Text * 6;
ADOTable1->Post();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Button10Click(TObject *Sender)
{
ADOTable1->Edit();
ADOTable1->FieldByName("Monthly Hours")->Clear();
ADOTable1->FieldByName("Expected Pay In €")->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::ComboBox1Change(TObject *Sender)
{
	translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Button13Click(TObject *Sender)
{
std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
std::unique_ptr<TMemoryStream> publicKey (new TMemoryStream);

if(Signatory1->GenerateKeys()){
Signatory1->StoreKeysToStream(privateKey.get(),
TKeyStoragePartSet() << partPrivate);

Signatory1->StoreKeysToStream(publicKey.get(),
TKeyStoragePartSet() << partPublic);

privateKey->SaveToFile("DecryptKey.bin");
publicKey->SaveToFile("EncryptKey.bin");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Button11Click(TObject *Sender)
{
String Hours = ADOTable1->FieldByName("Monthly Hours")->AsString;
String EncryptedHours;
std::unique_ptr<TMemoryStream> PKey (new TMemoryStream);

PKey->LoadFromFile("EncryptKey.bin");
Signatory1->LoadKeysFromStream(PKey.get(),
TKeyStoragePartSet() << partPublic);
Codec1->EncryptString(Hours, EncryptedHours, TEncoding::UTF8);

ADOTable1->Edit();
ADOTable1->FieldByName("Monthly Hours")->AsString = EncryptedHours;
ADOTable1->Post();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Button12Click(TObject *Sender)
{
std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
String DecryptedHours;

privateKey->LoadFromFile("DecryptKey.bin");
Signatory1->LoadKeysFromStream(privateKey.get(),
TKeyStoragePartSet() << partPrivate);

Codec1->DecryptString(DecryptedHours, ADOTable1->FieldByName("Monthly Hours")->AsString, TEncoding::UTF8);
HoursDecrypted->Text = DecryptedHours;
}
//---------------------------------------------------------------------------








void __fastcall TForm7::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::FormShow(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "\\..\\ProjektLanguage.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------




