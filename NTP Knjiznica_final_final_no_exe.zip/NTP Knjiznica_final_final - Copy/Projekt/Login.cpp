﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "EmployeeInterface.h"
#include "UserInterface.h"
#include "Login.h"
#include "AdminInterface.h"
#include <registry.hpp>
#include <map>
#include <IniFiles.hpp>
#include "Register.h"
#include "Homepage.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
 void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
	translation["Label1"] =  {
	{
		{"US", "Username"},
		{"HR", "Ime"}
	}
	};
	translation["Label2"] =  {
	{
		{"US", "Password"},
		{"HR", "Šifra"}
	}
	};

	translation["Login"] =  {
	{
		{"US", "Login"},
		{"HR", "Prijava"}
	}
	};
	translation["Register"] =  {
	{
		{"US", "Register"},
		{"HR", "Registriraj se"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Početna"}
	}
	};
}
//---------------------------------------------------------------------------

void __fastcall TForm2::LoginClick(TObject *Sender)
{
IdTCPClient1->Connect();
	IdTCPClient1->Socket->WriteLn(Username->Text);
	IdTCPClient1->Socket->WriteLn(Password->Text);

	 int odgovor = IdTCPClient1->Socket->ReadInt32();
     IdTCPClient1->Disconnect();

try {
    if (odgovor == 1) {
        Form5->Show();
        this->Hide();
    }
} catch (Exception &e) {
    ShowMessage("Error: " + e.Message);
}



	TIniFile *ini2;
	ini2 = new TIniFile(GetCurrentDir() + "Username.ini");
	ini2->WriteString("USERNAME INI", "Username->Text", Username->Text);
	delete ini2;


}
//---------------------------------------------------------------------------



void __fastcall TForm2::ComboBox1Change(TObject *Sender)
{
	 translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------



void __fastcall TForm2::FormCreate(TObject *Sender)
{
TIniFile *ini2;
ini2 = new TIniFile(GetCurrentDir() + "Username.ini");
Username->Text = ini2->ReadString("USERNAME INI","Username->Text","");
delete ini2;



}
//---------------------------------------------------------------------------

void __fastcall TForm2::RegisterClick(TObject *Sender)
{
Form1->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm2::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormShow(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "\\..\\ProjektLanguage.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

