//---------------------------------------------------------------------------

#ifndef AdminInterfaceH
#define AdminInterfaceH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <IdAuthentication.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdHTTP.hpp>
#include <IdTCPClient.hpp>
#include <IdTCPConnection.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>
#include <IdIOHandler.hpp>
#include <IdIOHandlerSocket.hpp>
#include <IdIOHandlerStack.hpp>
#include <IdSSL.hpp>
#include <IdSSLOpenSSL.hpp>
#include <Vcl.ComCtrls.hpp>
#include <IdIntercept.hpp>
#include <IdInterceptThrottler.hpp>
#include "uTPLb_BaseNonVisualComponent.hpp"
#include "uTPLb_Codec.hpp"
#include "uTPLb_CryptographicLibrary.hpp"
#include "uTPLb_Signatory.hpp"
#include <System.SysUtils.hpp>
#include <map>
//---------------------------------------------------------------------------
class TForm7 : public TForm
{
__published:	// IDE-managed Components
	TADOTable *ADOTable1;
	TDataSource *DataSource1;
	TDBGrid *DBGrid1;
	TIdHTTP *Download;
	TIdSSLIOHandlerSocketOpenSSL *IdSSLIOHandlerSocketOpenSSL1;
	TButton *Button1;
	TProgressBar *ProgressBar1;
	TButton *Button2;
	TIdInterceptThrottler *Throttler;
	TLabel *Label1;
	TButton *Button3;
	TButton *Button4;
	TButton *Button5;
	TEdit *FirstName;
	TEdit *LastName;
	TEdit *Username;
	TEdit *Password;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TButton *Button6;
	TADOQuery *ADOQuery1;
	TButton *Button8;
	TButton *Button7;
	TEdit *Hours;
	TButton *Button9;
	TButton *Button10;
	TLabel *Label6;
	TComboBox *ComboBox1;
	TButton *Button11;
	TButton *Button12;
	TButton *Button13;
	TCodec *Codec1;
	TCryptographicLibrary *CryptographicLibrary1;
	TSignatory *Signatory1;
	TEdit *HoursDecrypted;
	TButton *Home;
	TLabel *Label7;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall DownloadWorkBegin(TObject *ASender, TWorkMode AWorkMode, __int64 AWorkCountMax);
	void __fastcall DownloadWork(TObject *ASender, TWorkMode AWorkMode, __int64 AWorkCount);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall Button9Click(TObject *Sender);
	void __fastcall Button10Click(TObject *Sender);
	void __fastcall ComboBox1Change(TObject *Sender);
	void __fastcall Button13Click(TObject *Sender);
	void __fastcall Button11Click(TObject *Sender);
	void __fastcall Button12Click(TObject *Sender);
	void __fastcall HomeClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);



private:	// User declarations
public:		// User declarations
std::map<String, std::map<String, String>> translation;
	__fastcall TForm7(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm7 *Form7;
//---------------------------------------------------------------------------
#endif
