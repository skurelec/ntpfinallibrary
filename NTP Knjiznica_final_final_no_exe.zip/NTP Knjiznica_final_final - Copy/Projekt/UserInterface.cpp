//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "..\dll\mydllform.h"

#include "UserInterface.h"
#include "AdditionalInformation.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Signatory"
#pragma resource "*.dfm"
#include <registry.hpp>
#include <IniFiles.hpp>
#include <map>
#include <memory>
#include "Homepage.h"
TForm5 *Form5;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm5::TForm5(TComponent* Owner)
	: TForm(Owner)
{
    DBImage1->DoubleBuffered = true;

	translation["Label1"] =  {
	{
		{"US", "ISBN"},
		{"HR", "ISBN"}
	}
	};
	translation["Label2"] =  {
	{
		{"US", "Title"},
		{"HR", "Naslov"}
	}
	};
	translation["Label3"] =  {
	{
		{"US", "Author"},
		{"HR", "Autor"}
	}
	};
		translation["Button2"] =  {
	{
		{"US", "Library branches"},
		{"HR", "Fizicke knjiznice"}
	}
	};
		translation["Button3"] =  {
	{
		{"US", "Verify Signature"},
		{"HR", "Provjeri potpis"}
	}
	};
	translation["AditionalData"] =  {
	{
		{"US", "AditionalData"},
		{"HR", "Dodatni podatci"}
	}
	};
	translation["Label5"] =  {
	{
		{"US", "Filter by ISBN"},
		{"HR", "Filtriraj po ISBN-u"}
	}
	};
	translation["Filter"] =  {
	{
		{"US", "Filter"},
		{"HR", "Filtriraj"}
	}
	};
	translation["Clear"] =  {
	{
		{"US", "Clear"},
		{"HR", "Isprazni"}
	}
	};
	translation["Label7"] =  {
	{
		{"US", "Sort by Field"},
		{"HR", "Sortiraj po stupcu"}
	}
	};
	translation["Button1"] =  {
	{
		{"US", "Sort"},
		{"HR", "Sortiraj"}
	}
	};
	translation["Label4"] =  {
	{
		{"US", "Search by Title"},
		{"HR", "Pronadi po naslovu"}
	}
	};
	translation["Lookup"] =  {
	{
		{"US", "Search"},
		{"HR", "Pronadi"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Pocetna"}
	}
	};
}
//---------------------------------------------------------------------------
void __fastcall TForm5::AditionalDataClick(TObject *Sender)
{
String ISBN = DBEdit1->Text;
Form4->RESTRequest1->Resource = ISBN;
Form4->RESTRequest1->Execute();
Form4->Show();
}
//---------------------------------------------------------------------------


void __fastcall TForm5::FilterClick(TObject *Sender)
{
ADOTable1->Filter = "ISBN ="+ISBNFilter->Text;
ADOTable1->Filtered = true;

}
//---------------------------------------------------------------------------

void __fastcall TForm5::ClearClick(TObject *Sender)
{
ADOTable1->Filtered = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::LookupClick(TObject *Sender)
{
TLocateOptions SearchOptions;
SearchOptions.Clear();
SearchOptions << loPartialKey;
ADOTable1->Locate("Title", LookupText->Text,SearchOptions);
}
//---------------------------------------------------------------------------


void __fastcall TForm5::Button1Click(TObject *Sender)
{
ADOTable1->IndexFieldNames = ComboBox1->Text;

TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "SortbyColumn.ini");
ini->WriteString("SORT INI", "ComboBox1->Text", ComboBox1->Text);
delete ini;


}
//---------------------------------------------------------------------------


void __fastcall TForm5::FormCreate(TObject *Sender)
{
TIniFile *ini3;
ini3 = new TIniFile(GetCurrentDir() + "SortbyColumn.ini");
ComboBox1->Text = ini3->ReadString("SORT INI","ComboBox1->Text","");
delete ini3;

}
//---------------------------------------------------------------------------

void __fastcall TForm5::ComboBox2Change(TObject *Sender)
{
	translateForm(this, ComboBox2->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button2Click(TObject *Sender)
{
TFDLLForm* dllForm = new TFDLLForm(this);
dllForm->ShowModal();
delete dllForm;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button3Click(TObject *Sender)
{
std::unique_ptr<TMemoryStream> document(new TMemoryStream);
document ->LoadFromFile("poslovnice.dat");

std::unique_ptr<TMemoryStream> publicKey(new TMemoryStream);
publicKey->LoadFromFile("Public.bin");
Signatory1->LoadKeysFromStream(publicKey.get(),TKeyStoragePartSet()<< partPublic);

std::unique_ptr<TMemoryStream> signature(new TMemoryStream);
Signatory1->Sign(document.get(),signature.get());
signature->LoadFromFile("signature.bin");
TVerifyResult vr = Signatory1->Verify(document.get(),signature.get());
if(vr == vPass){
ShowMessage("Signature is valid");
}
else ShowMessage("Signature not valid");
}
//---------------------------------------------------------------------------


void __fastcall TForm5::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm5::FormShow(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "\\..\\ProjektLanguage.ini");
ComboBox2->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox2->Text, translation);
}
//---------------------------------------------------------------------------

