//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Homepage.h"
#include "Login.h"
#include "LoginEmployee.h"
#include "LoginAdmin.h"
#include <map>
#include <IniFiles.hpp>
#include "Register.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm6 *Form6;

//---------------------------------------------------------------------------
  void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm6::TForm6(TComponent* Owner)
	: TForm(Owner)
{
	translation["Button1"] =  {
	{
		{"US", "Login as User"},
		{"HR", "Prijava za korisnike"}
	}
	};
	translation["Button2"] =  {
	{
		{"US", "Login as Employee"},
		{"HR", "Prijava za radnike"}
	}
	};
	translation["Button3"] =  {
	{
		{"US", "Login as Admin"},
		{"HR", "Prijava za administratore"}
	}
	};
    translation["Button4"] =  {
	{
		{"US", "Register"},
		{"HR", "Registriraj se"}
	}
	};

}
//---------------------------------------------------------------------------
void __fastcall TForm6::Button1Click(TObject *Sender)
{
Form2->Show();
Form6->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TForm6::Button2Click(TObject *Sender)
{
Form8->Show();
Form6->Hide();

}
//---------------------------------------------------------------------------

void __fastcall TForm6::Button3Click(TObject *Sender)
{
Form9->Show();
Form6->Hide();

}
//---------------------------------------------------------------------------

void __fastcall TForm6::ComboBox1Change(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "Language.ini");
ini->WriteString("LANGUAGE INI", "ComboBox1->Text", ComboBox1->Text);
delete ini;

translateForm(this, ComboBox1->Text, translation);

}
//---------------------------------------------------------------------------



void __fastcall TForm6::Button4Click(TObject *Sender)
{
Form1->Show();
Form6->Hide();

}
//---------------------------------------------------------------------------

void __fastcall TForm6::FormCreate(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "Language.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------





