//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LoginAdmin.h"
#include <map>
#include "AdminInterface.h"
#include <IniFiles.hpp>
#include "Homepage.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TForm9 *Form9;
//---------------------------------------------------------------------------
  void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm9::TForm9(TComponent* Owner)
	: TForm(Owner)
{
translation["Label1"] =  {
	{
		{"US", "Username"},
		{"HR", "Korisnicko ime"}
	}
	};
translation["Label2"] =  {
	{
		{"US", "Password"},
		{"HR", "�ifra"}
	}
	};
translation["Login"] =  {
	{
		{"US", "Login"},
		{"HR", "Prijavi se"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Pocetna"}
	}
	};
}
//---------------------------------------------------------------------------

void __fastcall TForm9::LoginClick(TObject *Sender)
{
IdTCPClient3->Connect();
	 IdTCPClient3->Socket->WriteLn(Username->Text);
	 IdTCPClient3->Socket->WriteLn(Password->Text);

	 int odgovor = IdTCPClient3->Socket->ReadInt32();
     IdTCPClient3->Disconnect();

	 if(odgovor == 1){
     Form7->Show();
     this->Hide();
    }

}
//---------------------------------------------------------------------------


void __fastcall TForm9::ComboBox1Change(TObject *Sender)
{
	translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------


void __fastcall TForm9::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm9::FormShow(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "\\..\\ProjektLanguage.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

