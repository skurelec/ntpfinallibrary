﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <IdHashSHA.hpp>
#include <memory>
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::IdTCPServer1Execute(TIdContext *AContext)
{
bool found = false;
TIdHashSHA1* sha1 = new TIdHashSHA1;
String Username = AContext->Connection->Socket->ReadLn();
String Password = AContext->Connection->Socket->ReadLn();

String Sol;
if (Password.Length() < 6) {
    Sol = "TOP";
} else {
    Sol = "BOT";
}

String PossiblePapars[] = {"papar1", "papar2", "papar3"};

Login->First();
while (!Login->Eof) {
	if (Login->FieldByName("Username")->AsString.LowerCase() == Username.LowerCase()) {
		for (const String& Papar : PossiblePapars) {
			for (int i = 0; i < 2; ++i) {
				String Sol = (i == 0) ? "TOP" : "BOT";
				String HashedPassword = sha1->HashStringAsHex(Password + Sol + Papar);
				String BasePassword = Login->FieldByName("Password")->AsString;
				if (HashedPassword == BasePassword) {
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		break;
	}
	Login->Next();
}

if (found) {
	AContext->Connection->Socket->Write(1);
} else {
	ShowMessage("Error");
}


}


//---------------------------------------------------------------------------

void __fastcall TForm2::IdTCPServer2Execute(TIdContext *AContext)
{
bool found = false;
TIdHashSHA1* sha1 = new TIdHashSHA1;
String Username = AContext->Connection->Socket->ReadLn();
String Password = AContext->Connection->Socket->ReadLn();

String Sol;
if (Password.Length() < 6) {
    Sol = "TOP";
} else {
    Sol = "BOT";
}

String PossiblePapars[] = {"papar1", "papar2", "papar3"};

LoginE->First();
while (!LoginE->Eof) {
	if (LoginE->FieldByName("Username")->AsString.LowerCase() == Username.LowerCase()) {
        for (const String& Papar : PossiblePapars) {
			for (int i = 0; i < 2; ++i) {
				String Sol = (i == 0) ? "TOP" : "BOT";
                String HashedPassword = sha1->HashStringAsHex(Password + Sol + Papar);
				String BasePassword = LoginE->FieldByName("Password")->AsString;
				if (HashedPassword == BasePassword) {
                    found = true;
                    break;
                }
            }
            if (found) {
                break;
            }
        }
        break;
    }
    LoginE->Next();
}

if (found) {
	AContext->Connection->Socket->Write(1);
} else {
    ShowMessage("Error");
}

}
//---------------------------------------------------------------------------

void __fastcall TForm2::IdTCPServer3Execute(TIdContext *AContext)
{
bool found = false;
TIdHashSHA1* sha1 = new TIdHashSHA1;
String Username = AContext->Connection->Socket->ReadLn();
String Password = AContext->Connection->Socket->ReadLn();

String Sol;
if (Password.Length() < 6) {
    Sol = "TOP";
} else {
    Sol = "BOT";
}

String PossiblePapars[] = {"papar1", "papar2", "papar3"};

LoginA->First();
while (!LoginA->Eof) {
	if (LoginA->FieldByName("Username")->AsString.LowerCase() == Username.LowerCase()) {
        for (const String& Papar : PossiblePapars) {
			for (int i = 0; i < 2; ++i) {
				String Sol = (i == 0) ? "TOP" : "BOT";
                String HashedPassword = sha1->HashStringAsHex(Password + Sol + Papar);
                String BasePassword = LoginA->FieldByName("Password")->AsString;
				if (HashedPassword == BasePassword) {
                    found = true;
                    break;
                }
            }
            if (found) {
                break;
            }
        }
        break;
    }
    LoginA->Next();
}

if (found) {
	AContext->Connection->Socket->Write(1);
} else {
    ShowMessage("Error");
}

}
//---------------------------------------------------------------------------

void __fastcall TForm2::IdTCPServer4Execute(TIdContext *AContext)
{
UnicodeString naziv = AContext->Connection->Socket->ReadLn();
int velicina = AContext->Connection->Socket->ReadInt64();
std::unique_ptr<TFileStream> fs(new TFileStream(naziv, fmCreate));
AContext->Connection->Socket->ReadStream(fs.get(), velicina);
}

//---------------------------------------------------------------------------


