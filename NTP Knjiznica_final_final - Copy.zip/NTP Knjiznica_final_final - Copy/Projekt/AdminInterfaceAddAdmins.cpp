//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "AdminInterface.h"
#include <IdHashSHA.hpp>
#include "AdminInterfaceAddAdmins.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm10 *Form10;
//---------------------------------------------------------------------------
__fastcall TForm10::TForm10(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Button1Click(TObject *Sender)
{
Form7->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Button2Click(TObject *Sender)
{
String Sol;
if (Password->Text.Length() < 6) {
	Sol = "TOP";
} else {
    Sol = "BOT";
}

String PossiblePapars[] = {"papar1", "papar2", "papar3"};
String Papar = PossiblePapars[rand() % (sizeof(PossiblePapars) / sizeof(PossiblePapars[0]))];
TIdHashSHA1* sha1 = new TIdHashSHA1;
String hashedPassword = sha1->HashStringAsHex(Password->Text + Sol + Papar);

ADOTable1->Insert();
ADOTable1->FieldByName("First Name")->AsString = FirstName->Text;
ADOTable1->FieldByName("Last Name")->AsString = LastName->Text;
ADOTable1->FieldByName("Username")->AsString = Username->Text;
ADOTable1->FieldByName("Password")->AsString = hashedPassword;
ADOTable1->Post();
}
//---------------------------------------------------------------------------
