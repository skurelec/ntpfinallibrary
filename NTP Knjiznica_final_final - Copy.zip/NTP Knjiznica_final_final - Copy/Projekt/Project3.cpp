//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
#include "mydllform.h"
#include "mydllform.h"
//---------------------------------------------------------------------------
USEFORM("LoginEmployee.cpp", Form8);
USEFORM("LoginAdmin.cpp", Form9);
USEFORM("UserInterface.cpp", Form5);
USEFORM("Register.cpp", Form1);
USEFORM("EmployeeAddBooks.cpp", Form10);
USEFORM("AdminInterface.cpp", Form7);
USEFORM("AdditionalInformation.cpp", Form4);
USEFORM("Login.cpp", Form2);
USEFORM("LibraryBranches.cpp", Form12);
USEFORM("Homepage.cpp", Form6);
USEFORM("EmployeeInterface.cpp", Form3);
//---------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->CreateForm(__classid(TForm6), &Form6);
		Application->CreateForm(__classid(TForm7), &Form7);
		Application->CreateForm(__classid(TForm2), &Form2);
		Application->CreateForm(__classid(TForm5), &Form5);
		Application->CreateForm(__classid(TForm10), &Form10);
		Application->CreateForm(__classid(TForm12), &Form12);
		Application->CreateForm(__classid(TForm9), &Form9);
		Application->CreateForm(__classid(TForm1), &Form1);
		Application->CreateForm(__classid(TForm8), &Form8);
		Application->CreateForm(__classid(TForm3), &Form3);
		Application->CreateForm(__classid(TForm4), &Form4);
		Application->CreateForm(__classid(TFDLLForm), &FDLLForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
