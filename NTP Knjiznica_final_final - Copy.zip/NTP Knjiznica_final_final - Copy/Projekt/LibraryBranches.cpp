//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LibraryBranches.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <memory>
#include <vector>
#include <IniFiles.hpp>
#include <map>
TForm12 *Form12;
//---------------------------------------------------------------------------
__fastcall TForm12::TForm12(TComponent* Owner)
	: TForm(Owner)
{
	translation["Label1"] =  {
	{
		{"US", "Name"},
		{"HR", "Naziv"}
	}
	};
	translation["Label2"] =  {
	{
		{"US", "Address"},
		{"HR", "Adresa"}
	}
	};
	translation["Label3"] =  {
	{
		{"US", "Branch Number"},
		{"HR", "Broj Poslovnice"}
	}
	};
	translation["Label4"] =  {
	{
		{"US", "City"},
		{"HR", "Grad"}
	}
	};
	translation["Label5"] =  {
	{
		{"US", "Phone"},
		{"HR", "Telefon"}
	}
	};
	translation["Button1"] =  {
	{
		{"US", "Add"},
		{"HR", "Dodaj"}
	}
	};
	translation["Button2"] =  {
	{
		{"US", "Load"},
		{"HR", "Ucitaj"}
	}
	};
}
//---------------------------------------------------------------------------
class Binary {
public:
	wchar_t _naziv[10];
	float _inacica;

	Binary() {
		wcsncpy(_naziv, L"Binary", 10);
		_inacica = 1.0;
	}
};


class PoslovnicaKnjiznice {
public:
	wchar_t _naziv[50], _adresa[100], _grad[50], _telefon[25],_brojPoslovnice[10];

	PoslovnicaKnjiznice() {}
	PoslovnicaKnjiznice(wchar_t* naziv, wchar_t* adresa, wchar_t* brojPoslovnice, wchar_t* grad, wchar_t* telefon) {
		wcsncpy(_naziv, naziv, 50);
		wcsncpy(_adresa, adresa, 100);
		wcsncpy(_brojPoslovnice, brojPoslovnice, 10);
		wcsncpy(_grad, grad, 50);
		wcsncpy(_telefon, telefon, 25);
	}
};


void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);}










void __fastcall TForm12::Button2Click(TObject *Sender)
{
	 ListView1->Items->Clear();
	 std::unique_ptr<TMemoryStream> PosloniceStream(new TMemoryStream);
	 PosloniceStream->LoadFromFile("poslovnice.dat");

	 Binary Header;
	 PosloniceStream->Read(&Header, sizeof(Binary));

	 if(String(Header._naziv) != "Binary" || Header._inacica != 1.0){
		ShowMessage("Wrong Format!");
        return;
     }

	 PoslovnicaKnjiznice tmp;
	 int PoslovniceCount = (PosloniceStream->Size - sizeof(Header)) / sizeof(PoslovnicaKnjiznice);
	 for(int i = 0; i < PoslovniceCount; i++) {
		PosloniceStream->Read(&tmp, sizeof(PoslovnicaKnjiznice));

        ListView1->Items->Add();
		ListView1->Items->Item[i]->Caption = String(tmp._naziv);
		ListView1->Items->Item[i]->SubItems->Add(tmp._adresa);
		ListView1->Items->Item[i]->SubItems->Add(tmp._brojPoslovnice);
		ListView1->Items->Item[i]->SubItems->Add(tmp._grad);
        ListView1->Items->Item[i]->SubItems->Add(tmp._telefon);
	 }
}
//---------------------------------------------------------------------------
void __fastcall TForm12::Button1Click(TObject *Sender)
{
	std::vector<PoslovnicaKnjiznice> Poslovnice;
	Poslovnice.clear();
    for(int i = 0; i < ListView1->Items->Count; i++){
		Poslovnice.push_back(PoslovnicaKnjiznice(ListView1->Items->Item[i]->Caption.c_str(),
		ListView1->Items->Item[i]->SubItems->Strings[0].c_str(),
		ListView1->Items->Item[i]->SubItems->Strings[1].c_str(),
		ListView1->Items->Item[i]->SubItems->Strings[2].c_str(),
		ListView1->Items->Item[i]->SubItems->Strings[3].c_str()));
    }

	Poslovnice.push_back(PoslovnicaKnjiznice(Ime->Text.c_str(),
							Adresa->Text.c_str(),
							Broj->Text.c_str(),
							Grad->Text.c_str(),
							Telefon->Text.c_str()));
	Binary Header;
	std::unique_ptr<TFileStream> PoslovniceStream(new TFileStream("poslovnice.dat",fmCreate));
	PoslovniceStream->Write(&Header, sizeof(Binary));
	for(int i = 0; i < Poslovnice.size(); i++) {
		PoslovniceStream->Write(&Poslovnice[i], sizeof(PoslovnicaKnjiznice));
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm12::ComboBox1Change(TObject *Sender)
{
translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm12::FormShow(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "\\..\\ProjektLanguage.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

