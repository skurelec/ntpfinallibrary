
// ************************************************************************************************ //
//                                                                                                
//                                        XML Data Binding                                        
//                                                                                                
//         Generated on: 26/08/2023 12:31:31                                                      
//       Generated from: C:\Users\stjep\Desktop\Projektni zadatak\Projekt\EmergencyServices.xml   
//   Settings stored in: C:\Users\stjep\Desktop\Projektni zadatak\Projekt\EmergencyServices.xdb   
//                                                                                                
// ************************************************************************************************ //

#ifndef   EmergencyServicesH
#define   EmergencyServicesH

#include <System.hpp>
#include <Xml.Xmldom.hpp>
#include <Xml.XMLIntf.hpp>
#include <Xml.XMLDoc.hpp>
#include <XMLNodeImp.h>
#include <Xml.xmlutil.hpp>


// Forward Decls 

__interface IXMLemergencyServicesType;
typedef System::DelphiInterface<IXMLemergencyServicesType> _di_IXMLemergencyServicesType;
__interface IXMLserviceType;
typedef System::DelphiInterface<IXMLserviceType> _di_IXMLserviceType;

// IXMLemergencyServicesType 

__interface INTERFACE_UUID("{4FF8C739-53D2-473E-8189-BE427E5DB33D}") IXMLemergencyServicesType : public Xml::Xmlintf::IXMLNodeCollection
{
public:
public:
  // Property Accessors 
  virtual _di_IXMLserviceType __fastcall Get_service(int Index) = 0;
  // Methods & Properties 
  virtual _di_IXMLserviceType __fastcall Add() = 0;
  virtual _di_IXMLserviceType __fastcall Insert(const int Index) = 0;
  __property _di_IXMLserviceType service[int Index] = { read=Get_service };/* default */
};

// IXMLserviceType 

__interface INTERFACE_UUID("{195FF7A6-A1DC-4E53-9F89-5C828EB4E4E8}") IXMLserviceType : public Xml::Xmlintf::IXMLNode
{
public:
  // Property Accessors 
  virtual System::UnicodeString __fastcall Get_type() = 0;
  virtual System::UnicodeString __fastcall Get_phoneNumber() = 0;
  virtual void __fastcall Set_type(System::UnicodeString Value) = 0;
  virtual void __fastcall Set_phoneNumber(System::UnicodeString Value) = 0;
  // Methods & Properties 
  __property System::UnicodeString type = { read=Get_type, write=Set_type };
  __property System::UnicodeString phoneNumber = { read=Get_phoneNumber, write=Set_phoneNumber };
};

// Forward Decls 

class TXMLemergencyServicesType;
class TXMLserviceType;

// TXMLemergencyServicesType 

class TXMLemergencyServicesType : public Xml::Xmldoc::TXMLNodeCollection, public IXMLemergencyServicesType
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLemergencyServicesType 
  virtual _di_IXMLserviceType __fastcall Get_service(int Index);
  virtual _di_IXMLserviceType __fastcall Add();
  virtual _di_IXMLserviceType __fastcall Insert(const int Index);
public:
  virtual void __fastcall AfterConstruction(void);
};

// TXMLserviceType 

class TXMLserviceType : public Xml::Xmldoc::TXMLNode, public IXMLserviceType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLserviceType 
  virtual System::UnicodeString __fastcall Get_type();
  virtual System::UnicodeString __fastcall Get_phoneNumber();
  virtual void __fastcall Set_type(System::UnicodeString Value);
  virtual void __fastcall Set_phoneNumber(System::UnicodeString Value);
};

// Global Functions 

_di_IXMLemergencyServicesType __fastcall GetemergencyServices(Xml::Xmlintf::_di_IXMLDocument Doc);
_di_IXMLemergencyServicesType __fastcall GetemergencyServices(Xml::Xmldoc::TXMLDocument *Doc);
_di_IXMLemergencyServicesType __fastcall LoademergencyServices(const System::UnicodeString& FileName);
_di_IXMLemergencyServicesType __fastcall  NewemergencyServices();

#define TargetNamespace ""

#endif